import requests
from lxml import etree
import time,csv,re,os,sys
import Dict


# 获得最多50页的数据,返回一个二维列表
#用requests访问网页端的新浪微博，用etree的xpath来解析网页、查找所需元素

def getWB(inputKeyword, period, startPage):
    # 要使用微博的高级搜索，必须加上cookie
    headers = {"Cookie":"",
              'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 Edg/87.0.664.75'
    }
    pages = 0  # 读取的页数
    numWeb = 0  # 微博数

    result = []  # 普通微博 id 时间  转发数 评论数 点赞数 链接 内容
    #firstLine = ["博主id", "发帖时间", "转发数", "评论数", "点赞数", "链接", "内容"]#result.append(firstLine)

    # while (True):
    #通过while循环爬取最多50页数据
    while(pages<50):
        #
        # if (pages!=0 and pages%50==0):
        #     keyword = input('每爬取50页，可以输入 \'quit\' 提前终止,按回车继续爬取\n')  # 提前终止
        #     if keyword == 'quit':
        #         return result

        URL = getURL(inputKeyword, period, pages + startPage)
        r = requests.get(URL, headers=headers)  # 发送请求
        if (r.status_code != 200):#不等于200则失败
            print("请求网页内容失败")
            return result
            # sys.exit()
        else:
            print("请求访问第",(str)(pages+startPage),"页成功")
        html = etree.HTML(r.text)  # 已获取网页内容

        weiboContent = html.xpath("//p[@node-type='feed_list_content']")  # 该页的微博内容Content，可以获取不超过140字的文本和id
        fullWeiboContent = html.xpath("//p[@node-type='feed_list_content_full']")  # 完整微博内容和短微博不在同一个node上，可以获取完整文本和id
        # weiboAct = html.xpath("//div[@class='card-act']")#包含了微博三连信息的节点（点赞数、评论数、转发数）#没用到
        if len(weiboContent) == 0:
            print("在该条件下已经搜索不到结果了")
            hasMore = False
            return result

        # 要获取的信息：发博昵称，时间，转发数，评论数，点赞数，帖子链接，文本内容
        names = weiboContent[0].xpath("//p[@node-type='feed_list_content']/@nick-name")  # 所有发帖id，list

        # for循环
        i = 0  # 该页爬取的条数
        j = 0  # 该页爬取的长文章条数
        #通过for循环获取一个页面的内容
        for i in range(2, len(names)):
            weibo = weiboContent[i]

            name = weibo.attrib.get('nick-name')  # 获取id

            if len(fullWeiboContent) != 0 and j<len(fullWeiboContent):#在页面有内容时，fullWeiboContent也可能为空，即可能该页面没有长文微博
                longWeibo = fullWeiboContent[j]
                longName=longWeibo.attrib.get('nick-name')
            else:
                longWeibo = []
                longName=""

            if (name != None):  # 没被删
                postTime = weibo.xpath('../p[@class="from"]/a/text()')[0].strip().split(" ")[0]  # 时间
                link = weibo.xpath('../p[@class="from"]/a/@href')[0]  ##时间和链接在同一个节点

                # 转发数
                retweet = re.search("[1-9]\d*", weibo.xpath(
                    '../../../div[@class="card-act"]/ul/li[2]/a/text()')[0])  # 转发数
                if retweet != None:
                    retweet = retweet.group(0)
                else:
                    retweet = 0

                # 评论数
                comment = re.search("[1-9]\d*", weibo.xpath(
                    '../../../div[@class="card-act"]/ul/li[3]/a/text()')[0])
                if comment != None:
                    comment = comment.group(0)
                else:
                    comment = 0

                # 点赞数
                like = re.search("[1-9]\d*", weibo.xpath(
                    '../../../div[@class="card-act"]/ul/li[4]/a/text()')[0])
                if like != None:
                    like = like.group(0)
                else:
                    like = 0

                if ((name==longName)and longName!=""):  # 长微博
                    text = longWeibo.xpath('string(.)').strip().replace("收起全文d", "")  # 获取完整文本并去掉结尾的“收起全文”
                    j += 1
                else:  # 短微博（不超过140字）
                    text = weibo.xpath('string(.)').strip()  # 获取短文本

                row=[name, postTime, retweet, comment, like, link, text]
                result.append(row)
                numWeb += 1
                i += 1
        pages += 1
        print("爬虫暂时休眠中")
        print("目前共成功爬取" + (str)(numWeb) + "条微博")
        time.sleep(4)#网页端反爬虫很厉害，最好多设一点时间
    print("共成功爬取" + (str)(pages) + "页数据")
    print("共成功爬取" + (str)(numWeb) + "条微博")
    return result


#info_list是一个二维列表
def save(info_list,saveAddr,name):
    full_path = saveAddr+'/'+name + '.csv'
    if os.path.exists(full_path):
        with open(full_path,'a',encoding="utf-8",newline='') as f:#,encoding='utf-8'
            writer = csv.writer(f)
            try:
                writer.writerows(info_list)
            except UnicodeEncodeError:
                pass
    else:
        with open(full_path,'w+',encoding="utf-8",newline='') as f:#encoding='utf-8'
            writer = csv.writer(f)
            try:
                writer.writerows(info_list)
            except UnicodeEncodeError:
                pass
    return

#查询字典，得到 中文关键字 对应的 新浪url格式
def getKeyWord(inputKeyword):
    if (Dict.key_dict.__contains__(inputKeyword)==True):
        return Dict.key_dict[inputKeyword]

#查询字典，时间段对应的 新浪url格式
def getTimeWord(timeInput):
    if (Dict.time_dict.__contains__(timeInput)==True):
        return Dict.time_dict[timeInput]

#构造URL
def getURL(inputKeyword,timeInput,page):
    if (Dict.key_dict.__contains__(inputKeyword) != True | Dict.time_dict.__contains__(timeInput)!=True):
        print("Wrong!No this keyword in dictionary")
        sys.exit(1)
    return "https://s.weibo.com/weibo?q={}&typeall=1&suball=1&timescope=custom:{}&Refer=g&page={}".format(getKeyWord(inputKeyword),
                                                                                                          getTimeWord(timeInput),page)

if __name__ == '__main__':
    # inputKeyword = input("从关键字字典中选择中文关键字\n")
    # period = input("从时间字典中输入想选择的时间段\n")
    # startPage=(int)(input("开始搜索的页数，新浪的第一页为1，不是0\n"))
    # saveAddr = input("爬取数据csv的绝对路径\n")
    # name=input("存储数据的csv文件名\n")
    #循环爬取
    i=0
    j=0
    startPage=1
    totals=0
    for i in range(0,len(Dict.key_dict)):
        inputKeyword = Dict.keys[i]
        saveAddr = "D:\Data\Phase4\key{}".format(i+1)#修改
        print("现在爬取关键字:\n{}".format(Dict.keys[i]))

        for j in range(0,len(Dict.time_dict)):
            print("现在爬取第{}个时间段".format(j+1))
            period=Dict.times[j]
            name="wb{}".format(j+1)
            # 二维列表info_list
            info_list = getWB(inputKeyword, period, startPage)  # 获取数据并解析
            totals+=len(info_list)
            save(info_list, saveAddr, name)  # 存储数据
            print("数据成功存入！本时间段共爬取微博{}条.".format(len(info_list)))
    print("本轮共爬取{}条微博.".format(totals))