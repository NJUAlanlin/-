# 调用jieba，实现分词和TF-IDF算法的关键词抽取
import jieba,os
import jieba.analyse

#加载停词表，返回一个list
def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords
#对一个string分词，删去停词表中词汇，返回一个string
def seg_sentence(sentence):
    sentence_seged = jieba.cut(sentence.strip())
    stopwords = stopwordslist(os.path.join(os.getcwd(),'stopwords.txt'))  # 这里加载停用词的路径
    outstr = ''
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += " "
    return outstr
#返回一个list
def seg_sentence_list(sentence):
    sentence_seged = jieba.cut(sentence.strip())
    stopwords = stopwordslist(os.path.join(os.getcwd(),'stopwords.txt'))  # 这里加载停用词的路径
    ret_list = []
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                ret_list .append(word)
    return ret_list

#分词后调用jieba.analyse分析关键词，参数为一个string，返回一个列表，列表中每个元素为1个元组
def analyse(text):
    text=seg_sentence(text)#分词
    keywords = jieba.analyse.extract_tags(text, topK=35, withWeight=True)#返回40个关键词，带着权重
    for item in keywords:
        print(item[0], item[1])
    # print(type(keywords))
    # <class 'list'>
    return keywords

