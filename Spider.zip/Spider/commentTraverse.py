import os,wordFrequency

#该方法可以遍历评论文件：

path=["D:\Data\Effective\评论\第一阶段","D:\Data\Effective\评论\第二阶段","D:\Data\Effective\评论\第三阶段"]
commentPhase1=["12月8日", "12月9日", "12月10日", "12月11日", "12月12日", "12月13日", "12月14日", "12月15日", "12月16日", "12月17日", "12月18日", "12月19日"
              ,"12月20日","12月21日","12月22日","12月23日","12月24日","12月25日","12月26日","12月27日","12月28日","12月29日","12月30日","12月31日"
              ,"1月3日" ,"1月4日" ,"1月5日" ,"1月6日" ,"1月7日" ,"1月8日" ,"1月9日" ,"1月10日" ,"1月11日" ,"1月12日" ,"1月13日" ,"1月14日" ,"1月15日"
    , "1月16日" ,"1月17日" ,"1月18日" ,"1月19日" ,"1月20日" ,"1月21日" ,"1月22日"]
commentPhase2=["1月23日","1月24日","1月25日","1月26日","1月27日","1月28日","1月29日","1月30日","1月31日","2月1日","2月2日","2月3日"
               ,"2月4日","2月5日","2月6日","2月7日"]
commentPhase3=["2月10日","2月11日","2月12日","2月13日"]
comment=[commentPhase1,commentPhase2,commentPhase3]

supportive=["挺","致敬","感谢","谢谢","辛苦","心疼","胜利","必胜","赢","英雄","天使","医护","平安","平平安安"
,"伟大","爱心","志愿者","义工","祝愿","希望","祈祷","期待","加油","感动","好人","点赞","勇士","友谊","众志成城",
"万众一心","度过难关","暖心","善良","天佑中华","战士","最可爱","最美丽","坚强","真好","不错","凯旋","成功","八方支援",
"听党指挥","能打胜战","相信国家","相信中央","党中央","康复","友好","泪目"]

angry=["懒政","怠政","庸政","不作为","胡作为","乱作为","胡乱作为","烂透了","恨国","卖国","失职","砖家","叫兽","公知",
       "气死","形式主义","官僚","推诿扯皮","隐瞒","欺上瞒下","瞒报","蛀虫","国贼","蠹虫","恰钱","恰饭","恶之花",
       "断章取义","又蠢又坏","失望","红十字会","没有物资","没有防护","缺少物资","缺少防护","崩溃","被骗"
    ,"国难财","严惩","枪毙","判刑","推卸","鄂A0260w","死刑"]

anxious=["绝望","好可怕","太惨了","痛苦","焦虑","完蛋","要疯了","快疯了","涨价","弹尽粮绝","太累了","天灾人祸","痛心","自杀","倒闭","跳楼","没有希望"
         ,"多灾多难"]

yygqs=["壬","有用吗","急了","赢麻了","神友","兔友","自由","专制"]#比较难分析

#把所有文本内容都串进一个string里,方便用wordFrequency分析
keys=[]#三个阶段关键词的词典,二维list
text=[]

for i in range(0,len(comment)):
    commentNumber=0
    #
    support=0
    anger=0
    anxiety=0
    yygq=0
    #
    print("第{}阶段:\n".format(i + 1))
    print("————————————\n".format(i))
    longString = ""#用来分析关键词或是分词
    for j in range(0,len(comment[i])):

        full_path=os.path.join(path[i],comment[i][j]+".txt")
        try:
            text=[line.strip() for line in open(full_path, 'r', encoding='utf-8').readlines()]
        except FileNotFoundError:
            pass
        for line in text:
            longString+=" "+line
    text=wordFrequency.seg_sentence_list(longString)#经过jieba分词后的某一阶段的所有文本
    for word in text:
        commentNumber += 1
        if(word in supportive):#积极支持心态
            support+=1
        elif (word in angry):#愤怒心态
            anger+=1
        elif (word in anxious):#焦虑心态
            anxiety+=1
        elif (word in yygqs):#阴阳怪气
            yygq+=1
        else:
            continue
    print("明显的积极心态数{}".format(support))
    print("明显的愤怒心态数{}".format(anger))
    print("明显的焦虑心态数{}".format(anxiety))
    print("可能的阴阳怪气数{}".format(yygq))
    print("数量：{}".format(commentNumber))
    # key=wordFrequency.analyse(longString)#用于分析关键字和计算频率
    # print(key)


