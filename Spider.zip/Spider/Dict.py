#该文件是为了便于遍历的


dict={
    "央视网":"3266943013",#1969-2193 1882-1968 1834-1862  900-1631
    "央视新闻":"2656274875",#1918-2094  1770-1918  1720-1750  920-1560
    "中国新闻网": "1784473157",# 2825-3070 2610-2820 2545-2590 1300-2270
    "头条新闻": "1618051664",# 2590-2870 2415-2589  2370-2414   1400-2150
    "热点新闻": "1773041022",# 755-857  737-754 725-734 550-700
    "观察者网": "1887344341",#2317-2560 2228-2316 2185-2212 1450-2035
    # "紫光阁": "5467852665",# -45
    "中国政府网": "5000609535",  #

    # "央视新闻评论": "1663148275",#
}
mediaNameArray=["央视网", "央视新闻", "中国新闻网", "头条新闻", "热点新闻", "观察者网", "中国政府网"]
mediaValueArray=["3266943013", "2656274875", "1784473157", "1618051664", "1773041022", "1887344341","5000609535"]
phaseFor0=[1969,2193,1882,1968,1834,1862,900,1631]
phaseFor1=[1918,2094,1770,1918,1720,1750,920,1560]
phaseFor2=[2825,3070,2610,2820,2545,2590,1300,2270]
phaseFor3=[2590,2870,2415,2589,2370,2414,1400,2150]
phaseFor4=[755,857,737,754,725,734,550,700]
phaseFor5=[2317,2560,2228,2316,2185,2212,1450,2035]
phaseFor6=[]
phaseFor7=[]
phaseFor8=[]
phase=[phaseFor0,phaseFor1,phaseFor2,phaseFor3,phaseFor4,phaseFor5,phaseFor6,phaseFor7,phaseFor8]
hanzi=["一","二","三","四"]
hanzi2=["环球网","头条新闻","新华视点","央视网"]

huanqiuPhase1=["D:\Data\Effective\新闻\环球网\phase1","环球网getIndex",3600,3350]
huanqiuPhase2=["D:\Data\Effective\新闻\环球网\phase2","环球网getIndex",3349,3150]
huanqiuPhase3=["D:\Data\Effective\新闻\环球网\phase3","环球网getIndex",3100,3050]
huanqiuPhase4=["D:\Data\Effective\新闻\环球网\phase4","环球网getIndex",2688,1800]
huanqiuPhase=[huanqiuPhase1,huanqiuPhase2,huanqiuPhase3,huanqiuPhase4]

toutiaoPhase1=["D:\Data\Effective\新闻\头条新闻\phase1","头条新闻getIndex",2900,2550]
toutiaoPhase2=["D:\Data\Effective\新闻\头条新闻\phase2","头条新闻getIndex",2549,2450]
toutiaoPhase3=["D:\Data\Effective\新闻\头条新闻\phase3","头条新闻getIndex",2410,2380]
toutiaoPhase4=["D:\Data\Effective\新闻\头条新闻\phase4","头条新闻getIndex",2067,1500]
toutiaoPhase=[toutiaoPhase1,toutiaoPhase2,toutiaoPhase3,toutiaoPhase4]

xinhuaPhase1=["D:\Data\Effective\新闻\新华视点\phase1","新华视点getIndex",1989,1845]
xinhuaPhase2=["D:\Data\Effective\新闻\新华视点\phase2","新华视点getIndex",1844,1716]
xinhuaPhase3=["D:\Data\Effective\新闻\新华视点\phase3","新华视点getIndex",1701,1670]
xinhuaPhase4=["D:\Data\Effective\新闻\新华视点\phase4","新华视点getIndex",1499,893]
xinhuaPhase=[xinhuaPhase1,xinhuaPhase2,xinhuaPhase3,xinhuaPhase4]

yangshiPhase1=["D:\Data\Effective\新闻\央视网\phase1","getIndex",2193,1969]
yangshiPhase2=["D:\Data\Effective\新闻\央视网\phase2","getIndex",1968,1882]
yangshiPhase3=["D:\Data\Effective\新闻\央视网\phase3","getIndex",1862,1834]
yangshiPhase4=["D:\Data\Effective\新闻\央视网\phase4","getIndex",1631,931]
yangshiPhase=[yangshiPhase1,yangshiPhase2,yangshiPhase3,yangshiPhase4]

all=[huanqiuPhase,toutiaoPhase,xinhuaPhase,yangshiPhase]
