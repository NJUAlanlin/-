import os
import requests
import time
import Dict

for i in range(1, 6):#爬五个关键词
    mediaName=Dict.mediaNameArray[i]
    mediaValue=Dict.mediaValueArray[i]
    print("开始爬取微博账号{}".format(mediaName))
    for j in range(0,4):#爬4个阶段
        print("现在是第{}阶段".format(Dict.hanzi[j]))
        startPage = Dict.phase[i][2*j]
        page = startPage  # 起始页数

        while page <= Dict.phase[i][2*j+1]:  # 终止页数

            # file 为文件路径+文件名
            surfix = str(page) + '.json'
            full_path = 'D:\data\{}\第{}阶段\getIndex'.format(mediaName,Dict.hanzi[j]) + surfix
            fp = open(file=full_path, mode='w', encoding='utf-8')
            # if os.path.exists(full_path):
            #     fp = open(file=full_path, mode='w', encoding='utf-8')
            #     # with open(full_path,'a',encoding="utf-8",newline='') as f:#,encoding='utf-8'
            # else:
            #     fp = open(file=full_path, mode='w', encoding='utf-8')
            #     # with open(full_path,'w+',encoding="utf-8",newline='') as f:#encoding='utf-8'

            # 修改cookie
            # cookie = 'WEIBOCN_FROM=1110006030; ' \
            #          'SUB=_2A25NDRtSDeRhGeFK7FIS9ybIyDmIHXVu8aUarDV6PUJbkdAKLVrdkW1NQwr7AVUlxXuCqeKJUn4hSqMc_LpiVG5b; ' \
            #          '_T_WM=60525188506; MLOGIN=1; XSRF-TOKEN=0351ae; ' \
            #          'M_WEIBOCN_PARAMS=luicode%3D10000011%26lfid%3D231093_-_selffollowed%26fid%3D1005051618051664%26uicode' \
            #          '%3D10000011 '

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                              'Chrome/87.0.4280.141 Safari/537.36 Edg/87.0.664.75',

                "Cookie": "SINAGLOBAL=2369841446108.4585.1591957890437; wvr=6; un=1070298513@qq.com; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9Whq1fbIiYoK1cF4RvRnOnMF5JpX5KMhUgL.FoqX1hncShMfS0z2dJLoIEXLxKqL1--L1KMLxKBLBonLB-BLxK-LBo5L12qLxKqLBK-LBK5LxKqL1-eLBKnt; webim_unReadCount=%7B%22time%22%3A1611129088599%2C%22dm_pub_total%22%3A0%2C%22chat_group_client%22%3A0%2C%22chat_group_notice%22%3A0%2C%22allcountNum%22%3A61%2C%22msgbox%22%3A0%7D; ALF=1642679739; SSOLoginState=1611143740; SCF=AjsCiWUPkjO9EFeo-hUO7uZcmAQBwXD1TqwJQNiQia-lkuEO7igLLTwnWxAOaBl3H66koGRl2-74iyTvoYIBN1U.; SUB=_2A25NDGpsDeRhGeBK41oX9CnJzD6IHXVueNykrDV8PUNbmtANLXT8kW9NR2zOS4FexVreK2zkQZzUEUzZ8K7OgxGS; _s_tentry=login.sina.com.cn; UOR=,,cn.bing.com; Apache=6814505316683.788.1611143721424; ULV=1611143721445:82:17:9:6814505316683.788.1611143721424:1611134046872",

            }

            # 修改url
            # 人民日报uid2803301701
            url = 'https://m.weibo.cn/api/container/getIndex?type=uid&value={}&containerid=107603{}&page={}'.format(mediaValue,mediaValue, (str)(page))
            print(url)
            response = requests.get(url=url, headers=headers)
            if (response.status_code != 200):
                print("Wrong!")
                print("Status code:{}".format(response.status_code))
            fp.write(response.text)

            # while os.path.getsize(file) < 2048:
            #     print(url)
            #     response = requests.get(url=url, headers=headers)
            #     fp.seek(0)
            #     fp.truncate()
            #     fp.write(response.text)

            time.sleep(3)
            fp.close()
            page += 1
