#!/usr/bin/python
import json
i=1980
for i in range(1980,2000):
    print("page{}".format(i))
    f = 'D:\Data\{}\phase{}\getIndex'.format("央视网", "1") + str(i) + '.json'
    fp = open(f, 'r')
    content = fp.read()
    a = json.loads(content)

    print(type(a))
    print(a)
    fp.close()
