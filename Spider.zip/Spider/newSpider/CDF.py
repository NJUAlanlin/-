from json import JSONDecodeError
import numpy as np
import matplotlib.pyplot as plt
# from scipy.optimize import curve_fit
import matplotlib.mlab as mlab
from scipy.stats import norm
import json,Dict,csv,math,wordFrequency,re
import seaborn as sns

#————————————————————————————————————————————-分割线——————————————————————————————————————————————————————
#这个文件CDF本意是用来拟合新闻重要性的分布，对新闻作出筛选的，但是因为写法封装的不好，里面有循环可以 遍历我们的所有新闻
#所以为了方便用遍历，就在CDF里同时干了另外一件事：TF-IDF统计高频词


#高斯永远的神1：采用 mlab.normpdf 基于直方图的柱子数量、均值、方差来拟合曲线，
# 然后再用plot画出来，缺点就是画出的正态分布拟合曲线（红色虚线）不一定能很好反映数据的分布情况，
# 换句话说，就是强行画出来的正态分布曲线。
def GaussYongYuanDeShen1(list):
    # 这里填入你的数据list
    x = np.array(list)

    # 如果已经是array格式就不用转化了
    # n, bins, patches = plt.hist(x, 20, density=1, facecolor='blue', alpha=0.75)  #第二个参数是直方图柱子的数量
    mean = np.mean(x)  # 计算均值
    sigma = np.std(x)  # 标准差，方差开根
    # nunOfCols = 30  # 直方图柱子的数量
    # numOfCols=10
    numOfCols=5
    n, bins, patches = plt.hist(x, numOfCols, density=1, alpha=0.75)
    # 直方图函数，x为x轴的值，normed=1表示为概率密度，即和为一，绿色方块，色深参数0.5.返回n个概率，直方块左边线的x值，及各个方块对象
    y = norm.pdf(bins, mean, sigma)  # 拟合一条最佳高斯分布曲线y

    plt.grid(True)
    plt.plot(bins, y, 'r--')  # 绘制y的曲线
    plt.xlabel('values')  # 绘制x轴
    plt.ylabel('Probability')  # 绘制y轴
    plt.title('Histogram : $\mu$=' + str(round(mean, 2)) + ' $\sigma=$' + str(round(sigma, 2)))  # 中文标题 u'xxx'
    # plt.subplots_adjust(left=0.15)#左边距
    plt.show()
    print("u:{},σ:{}".format(mean,sigma))

#高斯永远的神2：后三次采用seaborn库中的 distplot 方法绘制，不一定拟合正态分布。
def GaussYongYuanDeShen2(list):
    # 这里填入你的数据list
    x = np.array(list)
    mean = np.mean(x)  # 计算均值
    sigma = np.std(x)  # 标准差，方差开根

    sns.set_palette("hls") #设置所有图的颜色，使用hls色彩空间
    sns.distplot(x,color="r",bins=45,kde=True)
    plt.show()
    print("u:{},σ:{}".format(mean,sigma))

def save(saveAddr,name,info_list):
    with open(saveAddr+"\\"+name,"w",newline="") as f:
        writer = csv.writer(f)
        try:
            # writer.writerow(["新闻的id标识","影响因子1"])
            # writer.writerow(["新闻的id标识","影响因子1","影响因子2"])
            # writer.writerow(["新闻的id标识","影响因子1","影响因子2","影响因子3"])

            writer.writerows(info_list)
        except UnicodeEncodeError:
            pass



#fileAddrs = []  # 记录地址和该新闻(微博)全名的
factors = []  # 影响因子
totalNews=0
eachMediaNews=[]
info_list=[]
standard=7#经过拟合分布。确定影响因子大于等于7为重要新闻
allTextToLongString= ""
for loop in range(0,len(Dict.all)):#有4个媒体

    thisNewsAmount=0

    for p in range(1, 5):  # 每个媒体共4个阶段
        i = Dict.all[loop][p - 1][2]

        while (i > Dict.all[loop][p - 1][3]):  # 每个阶段几百个json文件，电脑快起来给我干活了！

            path = Dict.all[loop][p - 1][0]
            fileName = Dict.all[loop][p - 1][1] + (str)(i) + ".json"
            try:
                fp = open("{}\{}".format(path, fileName), "r")
            except FileNotFoundError:
                pass
            try:  # 爬的移动端，辣鸡移动端加载数据很慢，很有可能爬不到，加个异常就不一样啦！异,常,永,远,的,神！
                jsonFile = json.loads(fp.read())
            except JSONDecodeError:
                pass
            # reposts = []  # 转发数
            # comments = []  # 评论数
            # attitudes = []  # 点赞数
            if (jsonFile != None and jsonFile['ok']!=0):
                newsList = jsonFile['data']['cards']
                for j in range(0, len(newsList)):
                    news = newsList[j]
                    totalNews += 1  # 总共新闻量加一
                    thisNewsAmount+=1
                    try:
                        reposts_count = news['mblog']['reposts_count']
                        comments_count = news['mblog']['comments_count']
                        attitudes_count = news['mblog']['attitudes_count']
                        # 处理：计算定义的影响因子
                        # factor = comments_count + 0.05 * attitudes_count + 0.5 * reposts_count  # 最原始的
                        factor=comments_count
                        sqrtFactor = math.sqrt(factor)  # 因为数据分布比较离谱，所以开个平方根减小极差，让数据分布
                        # 更好看、客观
                        # factor3 = sqrtFactor * 1.2 + 100
                        # sqrtFactor成功缩小了极值差，但是因为有太多低影响力的垃圾新闻，依然很难拟合分布
                        # factor3=1/2*sqrtFactor

                        #对数函数性质非常优良，能大大缩小极差，让分布更为均匀优美
                        factor3=math.log1p(factor)
                        factors.append(factor3)
                        newsName = "{}第{}阶段的{}第{}条微博".format(Dict.hanzi2[loop],p, fileName, j)

                        #重要新闻筛选,如果影响因子大于标准值（此处为7），那么就把 正则过得文本内容 加入一个长string里去，以便于jieba分词
                        if  (factor3>standard):
                            string=" "+re.sub(r"<(.[^<>]*)>*","",news['mblog']['text']).replace("#","")
                            # allTextToLongString= allTextToLongString + re.sub("\d", "", string)
                            allTextToLongString=allTextToLongString+string
                        # info_list.append([newsName, factor]) #写入CSV的信息
                        # info_list.append([newsName,factor,sqrtFactor])
                        info_list.append([newsName, factor, sqrtFactor, factor3])
                    except KeyError:
                        pass
                # end for
            # end if
            i -= 1# 为啥是-1？因为微博是把 最近的新闻放在 页码偏小的地方， 换句话说，页码越大，时间越早，我们分析数据，当然要从古到今
        # end while
    # end for

    eachMediaNews.append(thisNewsAmount)
    print("{}总共分析了{}条新闻".format(Dict.hanzi2[loop],thisNewsAmount))
#end for
# GaussYongYuanDeShen2(factors) 拟合分布用

keyWords=wordFrequency.analyse(allTextToLongString)
print(keyWords)

saveAddr="D:\Data\Effective"
saveName="全影响因子记录.csv"#拟合分布用
# saveName="高频率词.csv"#统计频率用
save(saveAddr,saveName,keyWords)
print("本次总共分析了{}条新闻".format(totalNews))