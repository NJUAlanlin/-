# 基于TF-IDF算法的关键词抽取
import jieba,os
import jieba.analyse

def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords

def seg_sentence(sentence):
    sentence_seged = jieba.cut(sentence.strip())
    stopwords = stopwordslist(os.path.join(os.getcwd(),'stopwords.txt'))  # 这里加载停用词的路径
    outstr = ''
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += " "
    return outstr

def seg_sentence_list(sentence):
    sentence_seged = jieba.cut(sentence.strip())
    stopwords = stopwordslist(os.path.join(os.getcwd(),'stopwords.txt'))  # 这里加载停用词的路径
    ret_list = []
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                ret_list .append(word)
    return ret_list

def analyse(text):
    text=seg_sentence(text)#分词
    keywords = jieba.analyse.extract_tags(text, topK=35, withWeight=True)#返回40个关键词，带着权重
    for item in keywords:
        print(item[0], item[1])
    # print(type(keywords))
    # <class 'list'>
    return keywords

